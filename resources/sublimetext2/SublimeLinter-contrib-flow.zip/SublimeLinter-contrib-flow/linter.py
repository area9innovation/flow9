#
# linter.py
# Linter for SublimeLinter3, a code checking framework for Sublime Text 3
#
# Written by lars
# Copyright (c) 2014 lars
#
# License: MIT
#

"""This module exports the Flow plugin class."""

from SublimeLinter.lint import Linter, util


class Flow(Linter):

    """Provides an interface to flow."""

    syntax = ('flow')
    cmd = 'lint3'
    regex = r"^(?:ERROR: )?(?P<file>...*?):(?P<line>[0-9]*):?([0-9]*)(?P<message>.*)"
    multiline = False
    line_col_base = (1, 1)
    tempfile_suffix = "flow"
    error_stream = util.STREAM_STDOUT


